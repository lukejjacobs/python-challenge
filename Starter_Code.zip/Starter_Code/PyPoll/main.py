import csv

file1 = r"C:\Users\lukej\Downloads\Starter_Code (2)\Starter_Code\PyPoll\Resources\election_data.csv"
file2 = r"C:\Users\lukej\Downloads\Starter_Code (2)\Starter_Code\PyPoll\Analysis\Analysis.txt"

Total_Votes = 0
y = 0
z = 0
winner = 0
canadites = []
canadite_votes = []
percentages = []
with open(file1) as csv_file:
    reader = csv.reader(csv_file)

    for rows in reader:
        if rows[0] != "Ballot ID":

            Total_Votes = Total_Votes + 1

            if rows[2] not in canadites:
                canadites.append(rows[2])
                canadite_votes.append(int(0))
            x = 0    
            while x < len(canadites) and rows[2] in canadites:    
                if rows[2] in canadites[x]:
                    canadite_votes[x] = canadite_votes[x] + 1
                    x = len(canadites) #kills while loop
                else: x = x + 1


while y < len(canadites):
    percentages.append((canadite_votes[y] * 100 / Total_Votes))
    percentages[y] = round(percentages[y], 3)
    if canadite_votes[winner] < canadite_votes[y]:
        winner = y
    y = y + 1

with open(file2, mode = "w") as txt:

    txt.write("Election Results \n")
    txt.write("--------------------------- \n")
    txt.write(f"Total Votes: {Total_Votes} \n")
    txt.write("--------------------------- \n")
    while z < len(canadites):
        txt.write(f"{canadites[z]}: {percentages[z]}% ({canadite_votes[z]})\n")
        z = z + 1
    txt.write("--------------------------- \n")
    txt.write(f"Winner: {canadites[winner]} \n")
    txt.write("--------------------------- \n")

z = 0

print("Election Results")
print("---------------------------")
print(f"Total Votes: {Total_Votes}")
print("---------------------------") 
while z < len(canadites):
        print(f"{canadites[z]}: {percentages[z]}% ({canadite_votes[z]})")
        z = z + 1
print("---------------------------")
print(f"Winner: {canadites[winner]}")
print("---------------------------")

#outcome is just for fun and could be helpful for someone looking back at the code
outcome = {"Canadites" : canadites, "Canadites Votes": canadite_votes, "percentages": percentages}