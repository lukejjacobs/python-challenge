import csv

file = r"C:\Users\lukej\Downloads\Starter_Code (2)\Starter_Code\PyBank\Resources\budget_data.csv"
write = r"C:\Users\lukej\Downloads\Starter_Code (2)\Starter_Code\PyBank\Analysis\Analysis.txt"
with open(file) as csvfile:
    csvreader = csv.reader(csvfile)

    header = next(csvreader)
    months = 0
    Total = 0
    IncreaseDate = ""
    IncreaseAmount = 0
    DecreaseDate = ""
    DecreaseAmount = 0
    Previous = 0
    done_with_start = False

    for rows in csvreader:
        if rows[0] != "Date":
            months = months + 1
            Total = Total + int(rows[1])
            
            if done_with_start == False:
                start = int(rows[1])
                done_with_start = True
            finished = int(rows[1])

            if IncreaseAmount <= (int(rows[1]) - Previous):
                IncreaseAmount = int(rows[1]) - Previous
                IncreaseDate = rows[0]
            
            if  int(rows[1]) - Previous <= DecreaseAmount:
                DecreaseAmount = int(rows[1]) - Previous
                DecreaseDate = rows[0]
            Previous = int(rows[1])
change = finished - start
AverageChange = round(change / (months - 1) , 2)

What_To_Say = ["Financial Analysis ",
               "--------------------------------- ",
               f"Total Months: {months} ",
               f"Total: ${Total} ",
               f"Average Change: ${AverageChange} ",
               f"Greatest Increase in Profits: {IncreaseDate} (${IncreaseAmount}) ",
               f"Greatest Decrease in Profits: {DecreaseDate} (${DecreaseAmount}) "]

with open(write, mode = "w") as txt_file:
    txt_file.write("Financial Analysis \n")
    txt_file.write("--------------------------------- \n")
    txt_file.write(f"Total Months: {months} \n")
    txt_file.write(f"Total: ${Total} \n")
    txt_file.write(f"Average Change: {AverageChange} \n")
    txt_file.write(f"Greatest Increase in Profits: {IncreaseDate} (${IncreaseAmount}) \n")
    txt_file.write(f"Greatest Decrease in Profits: {DecreaseDate} (${DecreaseAmount}) \n")
    
for things in What_To_Say:
    print(things)

git-graph.view
